

<div class="span6">
    <div class="panel panel-default panel-primary">
        <div class="panel-body">
            Panel content 1
        </div>
    </div>
    <div class="panel panel-default panel-primary">
        <div class="panel-body">
            Panel content 2
        </div>
    </div>
    <div class="panel panel-default panel-primary">
        <div class="panel-body">
            Panel content 3
        </div>
    </div>
    <div class="panel panel-default panel-primary">
        <div class="panel-body">
            Panel content 4
        </div>
    </div>
    <div class="panel panel-default panel-primary">
        <div class="panel-body">
            Panel content 5
        </div>
    </div>
</div>
<div class="span6">
    <h1 class="text-center"><i class="fa fa-repeat"></i> Start here</h1>
    <h2 class="text-center">Begin by selecting a Work Order</h2>
    <div class="row-fluid clearfix">
        <div class="span12 column">
            <a href="<?php echo site_url('WorkOrders/add'); ?>" class="btn btn-primary">+</a>
        </div>
    </div>
</div>
